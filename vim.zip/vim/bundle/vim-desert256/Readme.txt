Desert256 color scheme for vim
==============================

Downloaded from http://www.vim.org/scripts/script.php?script_id=1243

All credit goes to the author
